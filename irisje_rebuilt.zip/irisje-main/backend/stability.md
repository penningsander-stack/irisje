# 🧩 Irisje.nl – Stabiliteits- en Deploy-checklist

Dit document voorkomt herhaling van fouten die eerder optraden
(bijv. automatisch uitloggen, serverfouten of import-problemen).

Laatste update: 18 oktober 2025

---

## ⚙️ 1. Projectstructuur

Gebruik exact deze bestandsnamen (hoofdlettergevoelig):

