// frontend/js/config.js
export const apiBase = "https://irisje-backend.onrender.com";
